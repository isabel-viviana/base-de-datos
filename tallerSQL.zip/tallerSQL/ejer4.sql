CREATE DATABASE IF NOT EXISTS tiendax;
USE tiendax;

CREATE TABLE IF NOT EXISTS clientes(
Id_cliente int unique primary key,
nombre_cliente varchar(50) NOT NULL,
correo varchar(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS productos(
Id_producto int unique primary key,
nombre varchar(50) NOT NULL,
descripcion varchar(50) NOT NULL,
precio decimal(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS pedidos(
Id_pedido int unique primary key,
Id_cliente int NOT NULL,
Id_producto int NOT NULL,
unidades int NOT NULL,
fecha_pedido DATE NOT NULL,
CONSTRAINT fk_pedido_cliente foreign key(Id_cliente) references clientes(Id_cliente),
CONSTRAINT fk_pedido_producto foreign key(Id_producto) references productos(Id_producto)
);