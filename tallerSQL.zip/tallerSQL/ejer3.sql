CREATE DATABASE IF NOT EXISTS hospital;
USE hospital;

CREATE TABLE IF NOT EXISTS pacientes(
Id_paciente int unique primary key,
nombre_paciente varchar(50) NOT NULL,
telefono int NOT NULL
);

CREATE TABLE IF NOT EXISTS medicos(
Id_medico int unique primary key,
nombre_medico varchar(50) NOT NULL,
especialidad varchar(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS citas(
Id_citas int unique primary key,
Id_paciente int NOT NULL,
Id_medico int NOT NULL,
fecha_consulta date NOT NULL,
hora_consulta DATE NOT NULL,
CONSTRAINT fk_cita_paciente foreign key(Id_paciente) references pacientes(Id_paciente),
CONSTRAINT fk_cita_medico foreign key(Id_medico) references medicos(Id_medico)
);