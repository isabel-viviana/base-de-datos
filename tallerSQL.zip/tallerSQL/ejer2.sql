CREATE DATABASE IF NOT EXISTS universidad;
USE universidad;

CREATE TABLE IF NOT EXISTS estudiantes(
Id_estudiante int unique primary key,
nombre_estudiante varchar(50) NOT NULL,
direccion varchar(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS profesores(
Id_profesor int unique primary key,
nombre_profesor varchar(50) NOT NULL,
especialidad varchar(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS cursos(
Id_curso int unique primary key,
Id_estudiante int NOT NULL,
Id_profesor int NOT NULL,
nombre_curso varchar(50) NOT NULL,
num_creditos varchar(50) NOT NULL,
CONSTRAINT fk_curso_estudiante foreign key(Id_estudiante) references estudiantes(Id_estudiante),
CONSTRAINT fk_curso_profesor foreign key(Id_profesor) references profesores(Id_profesor)
);