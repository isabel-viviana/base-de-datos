CREATE DATABASE IF NOT EXISTS bibliotecax;
USE bibliotecax;

CREATE TABLE IF NOT EXISTS libros(
Id_libro int unique primary key,
titulo varchar(50) NOT NULL,
año_publicacion date NOT NULL
);

CREATE TABLE IF NOT EXISTS usuarios(
Id_usuario int unique primary key,
nombre_usuario varchar(50) NOT NULL,
direccion varchar(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS prestamos(
Id_prestamo int unique primary key,
Id_libro int NOT NULL,
Id_usuario int NOT NULL,
fecha_prestamo date NOT NULL,
Fecha_devolucion date NOT NULL,
CONSTRAINT fk_prestamo_libro foreign key(Id_libro) references libros(Id_libro),
CONSTRAINT fk_prestamo_usuario foreign key(Id_usuario) references usuarios(Id_usuario)
);